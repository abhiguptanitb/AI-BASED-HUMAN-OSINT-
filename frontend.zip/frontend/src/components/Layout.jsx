import Sidebar from "./Sidebar";
import { Outlet, useLocation } from "react-router-dom";

export default function Layout() {
  const location = useLocation();

  // Hide sidebar on login/signup
  const hideSidebar = location.pathname === "/login" || location.pathname === "/signup";

  return (
    <div className="flex">
      {!hideSidebar && <Sidebar />}
      <main className="flex-1 p-4">
        <Outlet />
      </main>
    </div>
  );
}
